/**
 *  \file   ioctl_message.h
 *  \brief  ioctl message format structure
 *  \author Quentin Lampin
 *  \date   2009
 **/
#include <include/modelutils.h>

#ifndef __message__
#define	__message__

/* no private functions yet */

#endif

