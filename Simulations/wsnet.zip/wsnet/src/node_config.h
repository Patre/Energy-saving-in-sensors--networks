/**
 *  \file   node_config.h
 *  \brief  Node declarations
 *  \author Guillaume Chelius & Elyes Ben Hamida
 *  \date   2007
 **/
#ifndef __node_config__
#define __node_config__

#include "xmlparser.h"


/* ************************************************** */
/* ************************************************** */
int parse_nodes(xmlNodeSetPtr nodeset);


#endif //__node_config__
