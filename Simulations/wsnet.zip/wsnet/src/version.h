/**
 *  \file   version.h
 *  \brief  wsnet current version
 *  \author Elyes Ben Hamida and Guillaume Chelius
 *  \date   2009
 **/

#ifndef __version__
#define	__version__

#define WSNET_VERSION_YEAR "9"
#define WSNET_VERSION_MONTH "07"

#endif

