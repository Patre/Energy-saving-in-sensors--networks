/**
 *  \file   environment_config.h
 *  \brief  Environment declarations
 *  \author Guillaume Chelius & Elyes Ben Hamida
 *  \date   2007
 **/
#ifndef __environment_config__
#define __environment_config__

#include "xmlparser.h"


/* ************************************************** */
/* ************************************************** */
int parse_environment(xmlNodeSetPtr nodeset);
void print_environment(void);


#endif //__environment_config__
